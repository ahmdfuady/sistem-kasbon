# Automated tests

Run all tests with one command from the project root:

    npm test

Stack: [Vitest](https://vitest.dev). Tests cover the pure business logic only
(no network or database needed):

| File | What it verifies |
|------|------------------|
| `validation.test.ts` | input validation and business rules (credit limit, locked customers, overpayment, phone/email/password/photo) |
| `utils.test.ts` | rupiah formatting, WhatsApp links and message templates, due-date calculation, text helpers |
| `analytics.test.ts` | running balance, overdue lists, 7-day cash flow, weekly change, top items |
